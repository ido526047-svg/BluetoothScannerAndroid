package com.example.bluetoothscanner;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 200;
    private static final long SCAN_DURATION_MS = 10000L;

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothLeScanner scanner;
    private boolean scanning = false;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, String> devices = new LinkedHashMap<>();
    private final ArrayList<String> rows = new ArrayList<>();
    private ArrayAdapter<String> listAdapter;

    private TextView statusView;
    private TextView countView;
    private Button scanButton;

    private final Runnable stopRunnable = this::stopScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 16);

        TextView title = new TextView(this);
        title.setText("فاحص البلوتوث القريب");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 8, 0, 18);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        statusView = new TextView(this);
        statusView.setText("جاهز للفحص");
        statusView.setTextSize(16);
        root.addView(statusView, new LinearLayout.LayoutParams(-1, -2));

        countView = new TextView(this);
        countView.setText("عدد الأجهزة: 0");
        countView.setTextSize(16);
        countView.setPadding(0, 8, 0, 12);
        root.addView(countView, new LinearLayout.LayoutParams(-1, -2));

        scanButton = new Button(this);
        scanButton.setText("ابدأ الفحص لمدة 10 ثوانٍ");
        root.addView(scanButton, new LinearLayout.LayoutParams(-1, -2));

        Button clearButton = new Button(this);
        clearButton.setText("مسح النتائج");
        root.addView(clearButton, new LinearLayout.LayoutParams(-1, -2));

        ListView listView = new ListView(this);
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows);
        listView.setAdapter(listAdapter);
        root.addView(listView, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView note = new TextView(this);
        note.setText("يعرض التطبيق أجهزة Bluetooth Low Energy (BLE) التي تبث إشاراتها. قد لا تظهر الأجهزة غير القابلة للاكتشاف.");
        note.setTextSize(12);
        note.setPadding(0, 12, 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);

        BluetoothManager manager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        bluetoothAdapter = manager != null ? manager.getAdapter() : null;

        scanButton.setOnClickListener(v -> beginScan());
        clearButton.setOnClickListener(v -> {
            devices.clear();
            rows.clear();
            listAdapter.notifyDataSetChanged();
            updateCount();
        });

        if (bluetoothAdapter == null) {
            statusView.setText("هذا الجهاز لا يدعم البلوتوث.");
            scanButton.setEnabled(false);
        }
    }

    private boolean hasRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
                    && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            }, REQUEST_PERMISSIONS);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
        }
    }

    private void beginScan() {
        if (bluetoothAdapter == null) {
            statusView.setText("البلوتوث غير مدعوم على هذا الجهاز.");
            return;
        }
        if (!hasRequiredPermissions()) {
            requestRequiredPermissions();
            return;
        }

        try {
            if (!bluetoothAdapter.isEnabled()) {
                startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
                statusView.setText("شغّل البلوتوث ثم اضغط بدء الفحص.");
                return;
            }
            scanner = bluetoothAdapter.getBluetoothLeScanner();
            if (scanner == null) {
                statusView.setText("تعذّر بدء الفحص. تأكد من تشغيل البلوتوث.");
                return;
            }

            devices.clear();
            rows.clear();
            listAdapter.notifyDataSetChanged();
            updateCount();

            scanner.startScan(scanCallback);
            scanning = true;
            scanButton.setEnabled(false);
            statusView.setText("جارٍ فحص أجهزة BLE لمدة 10 ثوانٍ...");
            handler.removeCallbacks(stopRunnable);
            handler.postDelayed(stopRunnable, SCAN_DURATION_MS);
        } catch (SecurityException e) {
            statusView.setText("لا توجد أذونات كافية للبلوتوث.");
        } catch (Exception e) {
            statusView.setText("تعذّر بدء الفحص: " + e.getMessage());
        }
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            if (result == null || result.getDevice() == null) return;
            runOnUiThread(() -> {
                try {
                    BluetoothDevice device = result.getDevice();
                    String address = device.getAddress();
                    if (address == null) return;

                    String name = device.getName();
                    if (name == null || name.trim().isEmpty()) name = "جهاز بدون اسم";
                    String line = name + "\n" + address + "   •   الإشارة: " + result.getRssi() + " dBm";

                    if (devices.containsKey(address)) {
                        devices.put(address, line);
                        int index = new ArrayList<>(devices.keySet()).indexOf(address);
                        if (index >= 0 && index < rows.size()) rows.set(index, line);
                    } else {
                        devices.put(address, line);
                        rows.add(line);
                    }
                    listAdapter.notifyDataSetChanged();
                    updateCount();
                } catch (SecurityException ignored) {
                    statusView.setText("يلزم منح إذن البلوتوث لعرض تفاصيل الأجهزة.");
                }
            });
        }

        @Override
        public void onScanFailed(int errorCode) {
            runOnUiThread(() -> {
                statusView.setText("فشل الفحص. رمز الخطأ: " + errorCode);
                stopScan();
            });
        }
    };

    private void stopScan() {
        handler.removeCallbacks(stopRunnable);
        if (scanning && scanner != null) {
            try {
                if (hasRequiredPermissions()) scanner.stopScan(scanCallback);
            } catch (SecurityException ignored) {
                // الأذونات قد تكون تغيّرت أثناء الفحص.
            } catch (Exception ignored) {
            }
        }
        scanning = false;
        if (scanButton != null) scanButton.setEnabled(true);
        if (statusView != null) statusView.setText("انتهى الفحص. يمكنك بدء فحص جديد.");
    }

    private void updateCount() {
        countView.setText("عدد الأجهزة المكتشفة: " + devices.size());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            boolean granted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) granted = false;
            }
            if (granted) {
                statusView.setText("تم منح الأذونات. اضغط بدء الفحص.");
            } else {
                statusView.setText("لم تُمنح الأذونات المطلوبة، لذلك لا يمكن بدء الفحص.");
                Toast.makeText(this, "اسمح بأذونات البلوتوث لتشغيل الفحص", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        stopScan();
        super.onDestroy();
    }
}
